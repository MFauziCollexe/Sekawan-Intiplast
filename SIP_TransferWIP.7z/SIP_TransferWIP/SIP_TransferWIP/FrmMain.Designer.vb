﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits DevExpress.XtraBars.Ribbon.RibbonForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.RibbonControl = New DevExpress.XtraBars.Ribbon.RibbonControl()
        Me.dateTanggal = New DevExpress.XtraBars.BarEditItem()
        Me.RepositoryItemDateEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemDateEdit()
        Me.txtShift = New DevExpress.XtraBars.BarEditItem()
        Me.RepositoryItemTextEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemTextEdit()
        Me.cbProcessType = New DevExpress.XtraBars.BarEditItem()
        Me.RepositoryItemComboBox1 = New DevExpress.XtraEditors.Repository.RepositoryItemComboBox()
        Me.lookWarehouse = New DevExpress.XtraBars.BarEditItem()
        Me.RepositoryItemLookUpEdit3 = New DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit()
        Me.SpReport9GetSelectedWHBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GSL13DataSet = New SIP_TransferWIP.GSL13DataSet()
        Me.cbFlag = New DevExpress.XtraBars.BarEditItem()
        Me.RepositoryItemComboBox3 = New DevExpress.XtraEditors.Repository.RepositoryItemComboBox()
        Me.btnView = New DevExpress.XtraBars.BarButtonItem()
        Me.btnSave = New DevExpress.XtraBars.BarButtonItem()
        Me.btnPrint = New DevExpress.XtraBars.BarButtonItem()
        Me.btnExit = New DevExpress.XtraBars.BarButtonItem()
        Me.RibbonPage1 = New DevExpress.XtraBars.Ribbon.RibbonPage()
        Me.RibbonPageGroup1 = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.RibbonPageGroup2 = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.RibbonPageGroup3 = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.RibbonPageGroup4 = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.RibbonPageGroup5 = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.RibbonPageGroup6 = New DevExpress.XtraBars.Ribbon.RibbonPageGroup()
        Me.RepositoryItemButtonEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.RepositoryItemLookUpEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit()
        Me.RepositoryItemLookUpEdit2 = New DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit()
        Me.RepositoryItemPopupContainerEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit()
        Me.RepositoryItemComboBox2 = New DevExpress.XtraEditors.Repository.RepositoryItemComboBox()
        Me.RibbonStatusBar = New DevExpress.XtraBars.Ribbon.RibbonStatusBar()
        Me.LayoutControl1 = New DevExpress.XtraLayout.LayoutControl()
        Me.SpSIPGetTraferWIPGridControl = New DevExpress.XtraGrid.GridControl()
        Me.SpSIPGetTraferWIPBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.bgvMain = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridView()
        Me.GridBand1 = New DevExpress.XtraGrid.Views.BandedGrid.GridBand()
        Me.colINTERNALID = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colMachineID = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colBOMName = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colInventoryID = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colInventoryName = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colUoM = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colUoMPack = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colBOMFlag = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.gridBand2 = New DevExpress.XtraGrid.Views.BandedGrid.GridBand()
        Me.colQtyPI = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQtyPackPI = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQty1 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQtyPack1 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQty2 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQtyPack2 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQty3 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQtyPack3 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQty4 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.colQtyPack4 = New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn()
        Me.LayoutControlGroup1 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.LayoutControlItem1 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.SpReport9Get_SelectedWHTableAdapter = New SIP_TransferWIP.GSL13DataSetTableAdapters.spReport9Get_SelectedWHTableAdapter()
        Me.Sp_SIPGetTraferWIPTableAdapter = New SIP_TransferWIP.GSL13DataSetTableAdapters.Sp_SIPGetTraferWIPTableAdapter()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.AlertControl1 = New DevExpress.XtraBars.Alerter.AlertControl(Me.components)
        Me.QSp_SIPInsUpdTraferWIP1 = New SIP_TransferWIP.GSL13DataSetTableAdapters.QSp_SIPInsUpdTraferWIP()
        CType(Me.RibbonControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemDateEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemDateEdit1.VistaTimeProperties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemComboBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemLookUpEdit3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SpReport9GetSelectedWHBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GSL13DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemComboBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemLookUpEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemLookUpEdit2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemPopupContainerEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemComboBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LayoutControl1.SuspendLayout()
        CType(Me.SpSIPGetTraferWIPGridControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SpSIPGetTraferWIPBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bgvMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RibbonControl
        '
        Me.RibbonControl.ExpandCollapseItem.Id = 0
        Me.RibbonControl.ExpandCollapseItem.Name = ""
        Me.RibbonControl.Items.AddRange(New DevExpress.XtraBars.BarItem() {Me.RibbonControl.ExpandCollapseItem, Me.dateTanggal, Me.txtShift, Me.cbProcessType, Me.lookWarehouse, Me.cbFlag, Me.btnView, Me.btnSave, Me.btnPrint, Me.btnExit})
        Me.RibbonControl.Location = New System.Drawing.Point(0, 0)
        Me.RibbonControl.MaxItemId = 17
        Me.RibbonControl.Name = "RibbonControl"
        Me.RibbonControl.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.RibbonPage1})
        Me.RibbonControl.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemDateEdit1, Me.RepositoryItemTextEdit1, Me.RepositoryItemButtonEdit1, Me.RepositoryItemLookUpEdit1, Me.RepositoryItemLookUpEdit2, Me.RepositoryItemPopupContainerEdit1, Me.RepositoryItemComboBox1, Me.RepositoryItemComboBox2, Me.RepositoryItemLookUpEdit3, Me.RepositoryItemComboBox3})
        Me.RibbonControl.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.[False]
        Me.RibbonControl.ShowExpandCollapseButton = DevExpress.Utils.DefaultBoolean.[False]
        Me.RibbonControl.ShowToolbarCustomizeItem = False
        Me.RibbonControl.Size = New System.Drawing.Size(767, 144)
        Me.RibbonControl.StatusBar = Me.RibbonStatusBar
        Me.RibbonControl.Toolbar.ShowCustomizeItem = False
        '
        'dateTanggal
        '
        Me.dateTanggal.Caption = "Tanggal    "
        Me.dateTanggal.Edit = Me.RepositoryItemDateEdit1
        Me.dateTanggal.Id = 1
        Me.dateTanggal.Name = "dateTanggal"
        Me.dateTanggal.Width = 100
        '
        'RepositoryItemDateEdit1
        '
        Me.RepositoryItemDateEdit1.AutoHeight = False
        Me.RepositoryItemDateEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemDateEdit1.DisplayFormat.FormatString = "dd-MMM-yyyy"
        Me.RepositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.RepositoryItemDateEdit1.EditFormat.FormatString = "dd-MMM-yyyy"
        Me.RepositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.RepositoryItemDateEdit1.Name = "RepositoryItemDateEdit1"
        Me.RepositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton()})
        '
        'txtShift
        '
        Me.txtShift.Caption = "Shift         "
        Me.txtShift.Edit = Me.RepositoryItemTextEdit1
        Me.txtShift.Id = 2
        Me.txtShift.Name = "txtShift"
        Me.txtShift.Width = 100
        '
        'RepositoryItemTextEdit1
        '
        Me.RepositoryItemTextEdit1.AutoHeight = False
        Me.RepositoryItemTextEdit1.Name = "RepositoryItemTextEdit1"
        '
        'cbProcessType
        '
        Me.cbProcessType.Caption = "Prosess        "
        Me.cbProcessType.Edit = Me.RepositoryItemComboBox1
        Me.cbProcessType.Id = 8
        Me.cbProcessType.Name = "cbProcessType"
        Me.cbProcessType.Width = 100
        '
        'RepositoryItemComboBox1
        '
        Me.RepositoryItemComboBox1.AutoHeight = False
        Me.RepositoryItemComboBox1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemComboBox1.Items.AddRange(New Object() {"CuttingExtruder", "Cutting", "Extruder", "Printing", "Mixing", "Lain"})
        Me.RepositoryItemComboBox1.Name = "RepositoryItemComboBox1"
        '
        'lookWarehouse
        '
        Me.lookWarehouse.Caption = "Warehouse  "
        Me.lookWarehouse.Edit = Me.RepositoryItemLookUpEdit3
        Me.lookWarehouse.Id = 10
        Me.lookWarehouse.Name = "lookWarehouse"
        Me.lookWarehouse.Width = 100
        '
        'RepositoryItemLookUpEdit3
        '
        Me.RepositoryItemLookUpEdit3.AutoHeight = False
        Me.RepositoryItemLookUpEdit3.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemLookUpEdit3.Columns.AddRange(New DevExpress.XtraEditors.Controls.LookUpColumnInfo() {New DevExpress.XtraEditors.Controls.LookUpColumnInfo("WarehouseID", "WarehouseID")})
        Me.RepositoryItemLookUpEdit3.DataSource = Me.SpReport9GetSelectedWHBindingSource
        Me.RepositoryItemLookUpEdit3.DisplayMember = "WarehouseID"
        Me.RepositoryItemLookUpEdit3.Name = "RepositoryItemLookUpEdit3"
        Me.RepositoryItemLookUpEdit3.NullText = ""
        Me.RepositoryItemLookUpEdit3.ValueMember = "InternalID"
        '
        'SpReport9GetSelectedWHBindingSource
        '
        Me.SpReport9GetSelectedWHBindingSource.DataMember = "spReport9Get_SelectedWH"
        Me.SpReport9GetSelectedWHBindingSource.DataSource = Me.GSL13DataSet
        '
        'GSL13DataSet
        '
        Me.GSL13DataSet.DataSetName = "GSL13DataSet"
        Me.GSL13DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cbFlag
        '
        Me.cbFlag.Caption = "Flag"
        Me.cbFlag.Edit = Me.RepositoryItemComboBox3
        Me.cbFlag.Id = 11
        Me.cbFlag.Name = "cbFlag"
        Me.cbFlag.Width = 100
        '
        'RepositoryItemComboBox3
        '
        Me.RepositoryItemComboBox3.AutoHeight = False
        Me.RepositoryItemComboBox3.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemComboBox3.Items.AddRange(New Object() {"IN", "OUT"})
        Me.RepositoryItemComboBox3.Name = "RepositoryItemComboBox3"
        '
        'btnView
        '
        Me.btnView.Caption = "View"
        Me.btnView.Id = 13
        Me.btnView.LargeGlyph = Global.SIP_TransferWIP.My.Resources.Resources.eye
        Me.btnView.Name = "btnView"
        '
        'btnSave
        '
        Me.btnSave.Caption = "Save"
        Me.btnSave.Id = 14
        Me.btnSave.LargeGlyph = Global.SIP_TransferWIP.My.Resources.Resources.save
        Me.btnSave.Name = "btnSave"
        '
        'btnPrint
        '
        Me.btnPrint.Caption = "Print"
        Me.btnPrint.Id = 15
        Me.btnPrint.LargeGlyph = Global.SIP_TransferWIP.My.Resources.Resources.print
        Me.btnPrint.Name = "btnPrint"
        '
        'btnExit
        '
        Me.btnExit.Caption = "Exit"
        Me.btnExit.Id = 16
        Me.btnExit.LargeGlyph = Global.SIP_TransferWIP.My.Resources.Resources.times_circle
        Me.btnExit.Name = "btnExit"
        '
        'RibbonPage1
        '
        Me.RibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.RibbonPageGroup1, Me.RibbonPageGroup2, Me.RibbonPageGroup3, Me.RibbonPageGroup4, Me.RibbonPageGroup5, Me.RibbonPageGroup6})
        Me.RibbonPage1.Name = "RibbonPage1"
        Me.RibbonPage1.Text = "Home"
        '
        'RibbonPageGroup1
        '
        Me.RibbonPageGroup1.ItemLinks.Add(Me.dateTanggal)
        Me.RibbonPageGroup1.ItemLinks.Add(Me.txtShift)
        Me.RibbonPageGroup1.Name = "RibbonPageGroup1"
        '
        'RibbonPageGroup2
        '
        Me.RibbonPageGroup2.ItemLinks.Add(Me.cbProcessType)
        Me.RibbonPageGroup2.ItemLinks.Add(Me.lookWarehouse)
        Me.RibbonPageGroup2.Name = "RibbonPageGroup2"
        '
        'RibbonPageGroup3
        '
        Me.RibbonPageGroup3.ItemLinks.Add(Me.cbFlag)
        Me.RibbonPageGroup3.Name = "RibbonPageGroup3"
        '
        'RibbonPageGroup4
        '
        Me.RibbonPageGroup4.ItemLinks.Add(Me.btnView)
        Me.RibbonPageGroup4.Name = "RibbonPageGroup4"
        '
        'RibbonPageGroup5
        '
        Me.RibbonPageGroup5.ItemLinks.Add(Me.btnSave)
        Me.RibbonPageGroup5.ItemLinks.Add(Me.btnPrint)
        Me.RibbonPageGroup5.Name = "RibbonPageGroup5"
        '
        'RibbonPageGroup6
        '
        Me.RibbonPageGroup6.ItemLinks.Add(Me.btnExit)
        Me.RibbonPageGroup6.Name = "RibbonPageGroup6"
        '
        'RepositoryItemButtonEdit1
        '
        Me.RepositoryItemButtonEdit1.AutoHeight = False
        Me.RepositoryItemButtonEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton()})
        Me.RepositoryItemButtonEdit1.Name = "RepositoryItemButtonEdit1"
        '
        'RepositoryItemLookUpEdit1
        '
        Me.RepositoryItemLookUpEdit1.AutoHeight = False
        Me.RepositoryItemLookUpEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemLookUpEdit1.Name = "RepositoryItemLookUpEdit1"
        '
        'RepositoryItemLookUpEdit2
        '
        Me.RepositoryItemLookUpEdit2.AutoHeight = False
        Me.RepositoryItemLookUpEdit2.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemLookUpEdit2.Name = "RepositoryItemLookUpEdit2"
        '
        'RepositoryItemPopupContainerEdit1
        '
        Me.RepositoryItemPopupContainerEdit1.AutoHeight = False
        Me.RepositoryItemPopupContainerEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemPopupContainerEdit1.Name = "RepositoryItemPopupContainerEdit1"
        '
        'RepositoryItemComboBox2
        '
        Me.RepositoryItemComboBox2.AutoHeight = False
        Me.RepositoryItemComboBox2.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.RepositoryItemComboBox2.Name = "RepositoryItemComboBox2"
        '
        'RibbonStatusBar
        '
        Me.RibbonStatusBar.Location = New System.Drawing.Point(0, 744)
        Me.RibbonStatusBar.Name = "RibbonStatusBar"
        Me.RibbonStatusBar.Ribbon = Me.RibbonControl
        Me.RibbonStatusBar.Size = New System.Drawing.Size(767, 31)
        '
        'LayoutControl1
        '
        Me.LayoutControl1.Controls.Add(Me.SpSIPGetTraferWIPGridControl)
        Me.LayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LayoutControl1.Location = New System.Drawing.Point(0, 144)
        Me.LayoutControl1.Name = "LayoutControl1"
        Me.LayoutControl1.Root = Me.LayoutControlGroup1
        Me.LayoutControl1.Size = New System.Drawing.Size(767, 600)
        Me.LayoutControl1.TabIndex = 2
        Me.LayoutControl1.Text = "LayoutControl1"
        '
        'SpSIPGetTraferWIPGridControl
        '
        Me.SpSIPGetTraferWIPGridControl.DataSource = Me.SpSIPGetTraferWIPBindingSource
        Me.SpSIPGetTraferWIPGridControl.Location = New System.Drawing.Point(12, 12)
        Me.SpSIPGetTraferWIPGridControl.MainView = Me.bgvMain
        Me.SpSIPGetTraferWIPGridControl.MenuManager = Me.RibbonControl
        Me.SpSIPGetTraferWIPGridControl.Name = "SpSIPGetTraferWIPGridControl"
        Me.SpSIPGetTraferWIPGridControl.Size = New System.Drawing.Size(743, 576)
        Me.SpSIPGetTraferWIPGridControl.TabIndex = 4
        Me.SpSIPGetTraferWIPGridControl.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.bgvMain})
        '
        'SpSIPGetTraferWIPBindingSource
        '
        Me.SpSIPGetTraferWIPBindingSource.DataMember = "Sp_SIPGetTraferWIP"
        Me.SpSIPGetTraferWIPBindingSource.DataSource = Me.GSL13DataSet
        '
        'bgvMain
        '
        Me.bgvMain.Bands.AddRange(New DevExpress.XtraGrid.Views.BandedGrid.GridBand() {Me.GridBand1, Me.gridBand2})
        Me.bgvMain.Columns.AddRange(New DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn() {Me.colINTERNALID, Me.colMachineID, Me.colBOMName, Me.colInventoryID, Me.colInventoryName, Me.colUoM, Me.colUoMPack, Me.colBOMFlag, Me.colQtyPI, Me.colQtyPackPI, Me.colQty1, Me.colQtyPack1, Me.colQty2, Me.colQtyPack2, Me.colQty3, Me.colQtyPack3, Me.colQty4, Me.colQtyPack4})
        Me.bgvMain.GridControl = Me.SpSIPGetTraferWIPGridControl
        Me.bgvMain.Name = "bgvMain"
        Me.bgvMain.OptionsFind.AlwaysVisible = True
        Me.bgvMain.OptionsView.ColumnAutoWidth = False
        '
        'GridBand1
        '
        Me.GridBand1.AppearanceHeader.Options.UseTextOptions = True
        Me.GridBand1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridBand1.Columns.Add(Me.colINTERNALID)
        Me.GridBand1.Columns.Add(Me.colMachineID)
        Me.GridBand1.Columns.Add(Me.colBOMName)
        Me.GridBand1.Columns.Add(Me.colInventoryID)
        Me.GridBand1.Columns.Add(Me.colInventoryName)
        Me.GridBand1.Columns.Add(Me.colUoM)
        Me.GridBand1.Columns.Add(Me.colUoMPack)
        Me.GridBand1.Columns.Add(Me.colBOMFlag)
        Me.GridBand1.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left
        Me.GridBand1.Name = "GridBand1"
        Me.GridBand1.Width = 769
        '
        'colINTERNALID
        '
        Me.colINTERNALID.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colINTERNALID.AppearanceHeader.Options.UseFont = True
        Me.colINTERNALID.AppearanceHeader.Options.UseTextOptions = True
        Me.colINTERNALID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colINTERNALID.FieldName = "INTERNALID"
        Me.colINTERNALID.Name = "colINTERNALID"
        Me.colINTERNALID.OptionsColumn.AllowFocus = False
        Me.colINTERNALID.OptionsColumn.ReadOnly = True
        Me.colINTERNALID.Width = 94
        '
        'colMachineID
        '
        Me.colMachineID.AppearanceCell.Options.UseTextOptions = True
        Me.colMachineID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colMachineID.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colMachineID.AppearanceHeader.Options.UseFont = True
        Me.colMachineID.AppearanceHeader.Options.UseTextOptions = True
        Me.colMachineID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colMachineID.FieldName = "MachineID"
        Me.colMachineID.Name = "colMachineID"
        Me.colMachineID.OptionsColumn.AllowFocus = False
        Me.colMachineID.OptionsColumn.FixedWidth = True
        Me.colMachineID.Visible = True
        '
        'colBOMName
        '
        Me.colBOMName.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colBOMName.AppearanceHeader.Options.UseFont = True
        Me.colBOMName.AppearanceHeader.Options.UseTextOptions = True
        Me.colBOMName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colBOMName.FieldName = "BOMName"
        Me.colBOMName.Name = "colBOMName"
        Me.colBOMName.OptionsColumn.AllowFocus = False
        Me.colBOMName.OptionsColumn.FixedWidth = True
        Me.colBOMName.Visible = True
        Me.colBOMName.Width = 182
        '
        'colInventoryID
        '
        Me.colInventoryID.AppearanceCell.Options.UseTextOptions = True
        Me.colInventoryID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colInventoryID.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colInventoryID.AppearanceHeader.Options.UseFont = True
        Me.colInventoryID.AppearanceHeader.Options.UseTextOptions = True
        Me.colInventoryID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colInventoryID.FieldName = "InventoryID"
        Me.colInventoryID.Name = "colInventoryID"
        Me.colInventoryID.OptionsColumn.AllowFocus = False
        Me.colInventoryID.Visible = True
        Me.colInventoryID.Width = 93
        '
        'colInventoryName
        '
        Me.colInventoryName.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colInventoryName.AppearanceHeader.Options.UseFont = True
        Me.colInventoryName.AppearanceHeader.Options.UseTextOptions = True
        Me.colInventoryName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colInventoryName.FieldName = "InventoryName"
        Me.colInventoryName.Name = "colInventoryName"
        Me.colInventoryName.OptionsColumn.AllowFocus = False
        Me.colInventoryName.Visible = True
        Me.colInventoryName.Width = 212
        '
        'colUoM
        '
        Me.colUoM.AppearanceCell.Options.UseTextOptions = True
        Me.colUoM.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colUoM.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colUoM.AppearanceHeader.Options.UseFont = True
        Me.colUoM.AppearanceHeader.Options.UseTextOptions = True
        Me.colUoM.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colUoM.FieldName = "UoM"
        Me.colUoM.Name = "colUoM"
        Me.colUoM.OptionsColumn.AllowFocus = False
        Me.colUoM.Visible = True
        Me.colUoM.Width = 56
        '
        'colUoMPack
        '
        Me.colUoMPack.AppearanceCell.Options.UseTextOptions = True
        Me.colUoMPack.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colUoMPack.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colUoMPack.AppearanceHeader.Options.UseFont = True
        Me.colUoMPack.AppearanceHeader.Options.UseTextOptions = True
        Me.colUoMPack.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colUoMPack.FieldName = "UoMPack"
        Me.colUoMPack.Name = "colUoMPack"
        Me.colUoMPack.OptionsColumn.AllowFocus = False
        Me.colUoMPack.Visible = True
        Me.colUoMPack.Width = 76
        '
        'colBOMFlag
        '
        Me.colBOMFlag.AppearanceCell.Options.UseTextOptions = True
        Me.colBOMFlag.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colBOMFlag.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colBOMFlag.AppearanceHeader.Options.UseFont = True
        Me.colBOMFlag.AppearanceHeader.Options.UseTextOptions = True
        Me.colBOMFlag.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colBOMFlag.FieldName = "BOMFlag"
        Me.colBOMFlag.Name = "colBOMFlag"
        Me.colBOMFlag.OptionsColumn.AllowFocus = False
        Me.colBOMFlag.Visible = True
        '
        'gridBand2
        '
        Me.gridBand2.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.gridBand2.AppearanceHeader.Options.UseFont = True
        Me.gridBand2.AppearanceHeader.Options.UseTextOptions = True
        Me.gridBand2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.gridBand2.Caption = "Qty"
        Me.gridBand2.Columns.Add(Me.colQtyPI)
        Me.gridBand2.Columns.Add(Me.colQtyPackPI)
        Me.gridBand2.Columns.Add(Me.colQty1)
        Me.gridBand2.Columns.Add(Me.colQtyPack1)
        Me.gridBand2.Columns.Add(Me.colQty2)
        Me.gridBand2.Columns.Add(Me.colQtyPack2)
        Me.gridBand2.Columns.Add(Me.colQty3)
        Me.gridBand2.Columns.Add(Me.colQtyPack3)
        Me.gridBand2.Columns.Add(Me.colQty4)
        Me.gridBand2.Columns.Add(Me.colQtyPack4)
        Me.gridBand2.Name = "gridBand2"
        Me.gridBand2.Width = 1000
        '
        'colQtyPI
        '
        Me.colQtyPI.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQtyPI.AppearanceHeader.Options.UseFont = True
        Me.colQtyPI.AppearanceHeader.Options.UseTextOptions = True
        Me.colQtyPI.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQtyPI.DisplayFormat.FormatString = "n2"
        Me.colQtyPI.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQtyPI.FieldName = "QtyPI"
        Me.colQtyPI.Name = "colQtyPI"
        Me.colQtyPI.OptionsColumn.ReadOnly = True
        Me.colQtyPI.Visible = True
        Me.colQtyPI.Width = 100
        '
        'colQtyPackPI
        '
        Me.colQtyPackPI.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQtyPackPI.AppearanceHeader.Options.UseFont = True
        Me.colQtyPackPI.AppearanceHeader.Options.UseTextOptions = True
        Me.colQtyPackPI.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQtyPackPI.DisplayFormat.FormatString = "n2"
        Me.colQtyPackPI.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQtyPackPI.FieldName = "QtyPackPI"
        Me.colQtyPackPI.Name = "colQtyPackPI"
        Me.colQtyPackPI.OptionsColumn.ReadOnly = True
        Me.colQtyPackPI.Visible = True
        Me.colQtyPackPI.Width = 100
        '
        'colQty1
        '
        Me.colQty1.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQty1.AppearanceHeader.Options.UseFont = True
        Me.colQty1.AppearanceHeader.Options.UseTextOptions = True
        Me.colQty1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQty1.DisplayFormat.FormatString = "n2"
        Me.colQty1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQty1.FieldName = "Qty1"
        Me.colQty1.Name = "colQty1"
        Me.colQty1.Visible = True
        Me.colQty1.Width = 100
        '
        'colQtyPack1
        '
        Me.colQtyPack1.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQtyPack1.AppearanceHeader.Options.UseFont = True
        Me.colQtyPack1.AppearanceHeader.Options.UseTextOptions = True
        Me.colQtyPack1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQtyPack1.DisplayFormat.FormatString = "n2"
        Me.colQtyPack1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQtyPack1.FieldName = "QtyPack1"
        Me.colQtyPack1.Name = "colQtyPack1"
        Me.colQtyPack1.Visible = True
        Me.colQtyPack1.Width = 100
        '
        'colQty2
        '
        Me.colQty2.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQty2.AppearanceHeader.Options.UseFont = True
        Me.colQty2.AppearanceHeader.Options.UseTextOptions = True
        Me.colQty2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQty2.DisplayFormat.FormatString = "n2"
        Me.colQty2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQty2.FieldName = "Qty2"
        Me.colQty2.Name = "colQty2"
        Me.colQty2.Visible = True
        Me.colQty2.Width = 100
        '
        'colQtyPack2
        '
        Me.colQtyPack2.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQtyPack2.AppearanceHeader.Options.UseFont = True
        Me.colQtyPack2.AppearanceHeader.Options.UseTextOptions = True
        Me.colQtyPack2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQtyPack2.DisplayFormat.FormatString = "n2"
        Me.colQtyPack2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQtyPack2.FieldName = "QtyPack2"
        Me.colQtyPack2.Name = "colQtyPack2"
        Me.colQtyPack2.Visible = True
        Me.colQtyPack2.Width = 100
        '
        'colQty3
        '
        Me.colQty3.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQty3.AppearanceHeader.Options.UseFont = True
        Me.colQty3.AppearanceHeader.Options.UseTextOptions = True
        Me.colQty3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQty3.DisplayFormat.FormatString = "n2"
        Me.colQty3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQty3.FieldName = "Qty3"
        Me.colQty3.Name = "colQty3"
        Me.colQty3.Visible = True
        Me.colQty3.Width = 100
        '
        'colQtyPack3
        '
        Me.colQtyPack3.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQtyPack3.AppearanceHeader.Options.UseFont = True
        Me.colQtyPack3.AppearanceHeader.Options.UseTextOptions = True
        Me.colQtyPack3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQtyPack3.DisplayFormat.FormatString = "n2"
        Me.colQtyPack3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQtyPack3.FieldName = "QtyPack3"
        Me.colQtyPack3.Name = "colQtyPack3"
        Me.colQtyPack3.Visible = True
        Me.colQtyPack3.Width = 100
        '
        'colQty4
        '
        Me.colQty4.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQty4.AppearanceHeader.Options.UseFont = True
        Me.colQty4.AppearanceHeader.Options.UseTextOptions = True
        Me.colQty4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQty4.DisplayFormat.FormatString = "n2"
        Me.colQty4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQty4.FieldName = "Qty4"
        Me.colQty4.Name = "colQty4"
        Me.colQty4.Visible = True
        Me.colQty4.Width = 100
        '
        'colQtyPack4
        '
        Me.colQtyPack4.AppearanceHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.colQtyPack4.AppearanceHeader.Options.UseFont = True
        Me.colQtyPack4.AppearanceHeader.Options.UseTextOptions = True
        Me.colQtyPack4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.colQtyPack4.DisplayFormat.FormatString = "n2"
        Me.colQtyPack4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.colQtyPack4.FieldName = "QtyPack4"
        Me.colQtyPack4.Name = "colQtyPack4"
        Me.colQtyPack4.Visible = True
        Me.colQtyPack4.Width = 100
        '
        'LayoutControlGroup1
        '
        Me.LayoutControlGroup1.CustomizationFormText = "LayoutControlGroup1"
        Me.LayoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.[True]
        Me.LayoutControlGroup1.GroupBordersVisible = False
        Me.LayoutControlGroup1.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.LayoutControlItem1})
        Me.LayoutControlGroup1.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlGroup1.Name = "LayoutControlGroup1"
        Me.LayoutControlGroup1.Size = New System.Drawing.Size(767, 600)
        Me.LayoutControlGroup1.Text = "LayoutControlGroup1"
        Me.LayoutControlGroup1.TextVisible = False
        '
        'LayoutControlItem1
        '
        Me.LayoutControlItem1.Control = Me.SpSIPGetTraferWIPGridControl
        Me.LayoutControlItem1.CustomizationFormText = "LayoutControlItem1"
        Me.LayoutControlItem1.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlItem1.Name = "LayoutControlItem1"
        Me.LayoutControlItem1.Size = New System.Drawing.Size(747, 580)
        Me.LayoutControlItem1.Text = "LayoutControlItem1"
        Me.LayoutControlItem1.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem1.TextToControlDistance = 0
        Me.LayoutControlItem1.TextVisible = False
        '
        'SpReport9Get_SelectedWHTableAdapter
        '
        Me.SpReport9Get_SelectedWHTableAdapter.ClearBeforeFill = True
        '
        'Sp_SIPGetTraferWIPTableAdapter
        '
        Me.Sp_SIPGetTraferWIPTableAdapter.ClearBeforeFill = True
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(767, 775)
        Me.Controls.Add(Me.LayoutControl1)
        Me.Controls.Add(Me.RibbonStatusBar)
        Me.Controls.Add(Me.RibbonControl)
        Me.Name = "FrmMain"
        Me.Ribbon = Me.RibbonControl
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.StatusBar = Me.RibbonStatusBar
        Me.Text = "Transfer WIP"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.RibbonControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemDateEdit1.VistaTimeProperties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemDateEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemTextEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemComboBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemLookUpEdit3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SpReport9GetSelectedWHBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GSL13DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemComboBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemLookUpEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemLookUpEdit2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemPopupContainerEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemComboBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LayoutControl1.ResumeLayout(False)
        CType(Me.SpSIPGetTraferWIPGridControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SpSIPGetTraferWIPBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bgvMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents RibbonControl As DevExpress.XtraBars.Ribbon.RibbonControl
    Friend WithEvents RibbonPage1 As DevExpress.XtraBars.Ribbon.RibbonPage
    Friend WithEvents RibbonPageGroup1 As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Friend WithEvents RibbonStatusBar As DevExpress.XtraBars.Ribbon.RibbonStatusBar
    Friend WithEvents LayoutControl1 As DevExpress.XtraLayout.LayoutControl
    Friend WithEvents SpSIPGetTraferWIPGridControl As DevExpress.XtraGrid.GridControl
    Friend WithEvents LayoutControlGroup1 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents LayoutControlItem1 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents dateTanggal As DevExpress.XtraBars.BarEditItem
    Friend WithEvents RepositoryItemDateEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemDateEdit
    Friend WithEvents txtShift As DevExpress.XtraBars.BarEditItem
    Friend WithEvents RepositoryItemTextEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemTextEdit
    Friend WithEvents RepositoryItemLookUpEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit
    Friend WithEvents RibbonPageGroup2 As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Friend WithEvents RepositoryItemButtonEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents cbProcessType As DevExpress.XtraBars.BarEditItem
    Friend WithEvents RepositoryItemComboBox1 As DevExpress.XtraEditors.Repository.RepositoryItemComboBox
    Friend WithEvents lookWarehouse As DevExpress.XtraBars.BarEditItem
    Friend WithEvents RepositoryItemLookUpEdit3 As DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit
    Friend WithEvents SpReport9GetSelectedWHBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GSL13DataSet As SIP_TransferWIP.GSL13DataSet
    Friend WithEvents cbFlag As DevExpress.XtraBars.BarEditItem
    Friend WithEvents RepositoryItemComboBox3 As DevExpress.XtraEditors.Repository.RepositoryItemComboBox
    Friend WithEvents RepositoryItemLookUpEdit2 As DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit
    Friend WithEvents RepositoryItemPopupContainerEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit
    Friend WithEvents RepositoryItemComboBox2 As DevExpress.XtraEditors.Repository.RepositoryItemComboBox
    Friend WithEvents SpReport9Get_SelectedWHTableAdapter As SIP_TransferWIP.GSL13DataSetTableAdapters.spReport9Get_SelectedWHTableAdapter
    Friend WithEvents RibbonPageGroup3 As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Friend WithEvents btnView As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnSave As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents RibbonPageGroup4 As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Friend WithEvents SpSIPGetTraferWIPBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Sp_SIPGetTraferWIPTableAdapter As SIP_TransferWIP.GSL13DataSetTableAdapters.Sp_SIPGetTraferWIPTableAdapter
    Friend WithEvents bgvMain As DevExpress.XtraGrid.Views.BandedGrid.BandedGridView
    Friend WithEvents GridBand1 As DevExpress.XtraGrid.Views.BandedGrid.GridBand
    Friend WithEvents colINTERNALID As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colMachineID As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colBOMName As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colInventoryID As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colInventoryName As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colUoM As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colUoMPack As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colBOMFlag As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents gridBand2 As DevExpress.XtraGrid.Views.BandedGrid.GridBand
    Friend WithEvents colQtyPI As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQtyPackPI As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQty1 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQty2 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQty3 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQty4 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents btnPrint As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnExit As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents RibbonPageGroup5 As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Friend WithEvents RibbonPageGroup6 As DevExpress.XtraBars.Ribbon.RibbonPageGroup
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents colQtyPack1 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQtyPack2 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQtyPack3 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents colQtyPack4 As DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn
    Friend WithEvents AlertControl1 As DevExpress.XtraBars.Alerter.AlertControl
    Friend WithEvents QSp_SIPInsUpdTraferWIP1 As SIP_TransferWIP.GSL13DataSetTableAdapters.QSp_SIPInsUpdTraferWIP


End Class
