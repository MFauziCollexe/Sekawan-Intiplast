﻿Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraEditors

Public Class FrmMain
    Private Sub BarButtonItem1_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnView.ItemClick

        refresh_view()
    End Sub

    Private Sub refresh_view()
        Dim ProccessType, Flag, WHInternalID As String
        Dim shift As Integer
        Dim Periode As Date

        ProccessType = cbProcessType.EditValue
        WHInternalID = lookWarehouse.EditValue.ToString
        Flag = cbFlag.EditValue
        Periode = dateTanggal.EditValue
        shift = txtShift.EditValue

        Try
            'Me.Sp_SIPGetTraferWIPTableAdapter.Fill(Me.GSL13DataSet.Sp_SIPGetTraferWIP, Periode, shift, WHInternalID, ProccessType, Flag)
            Me.Sp_SIPGetTraferWIPTableAdapter.Fill(Me.GSL13DataSet.Sp_SIPGetTraferWIP, "2022-06-13", 1, "143", "Cutting", "0")
            bgvMain.ExpandAllGroups()
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub

    Private Sub btnPrint_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnPrint.ItemClick
        bgvMain.ShowPrintPreview()
    End Sub

    Private Sub cbProcessType_EditValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbProcessType.EditValueChanged
        Me.SpReport9Get_SelectedWHTableAdapter.Fill(Me.GSL13DataSet.spReport9Get_SelectedWH, cbProcessType.EditValue)
    End Sub

    Private Sub btnSave_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnSave.ItemClick
        Dim _getInternalID, _BomFlag, _WHInternalid, _InvInternalID, _UserModified, _companyid, _giiservername, _Shift,
            _DestinationType, _Transporter, _TruckNo, _Remarks, _Status, _Cropyear As String
        Dim _Q1, _Q2, _Q3, _Q4, _QPack1, _QPack2, _QPack3, _QPack4 As Decimal
        Dim _Destination, _WHInternalID1, _InternalID, _Void As Integer
        Dim _ShippingDate As Date

        _getInternalID = bgvMain.GetFocusedRowCellValue("INTERNALID").ToString()
        _InvInternalID = bgvMain.GetFocusedRowCellValue("InvInternalID").ToString()
        _Q1 = bgvMain.GetFocusedRowCellValue("Qty1").ToString()
        _Q2 = bgvMain.GetFocusedRowCellValue("Qty2").ToString()
        _Q3 = bgvMain.GetFocusedRowCellValue("Qty3").ToString()
        _Q4 = bgvMain.GetFocusedRowCellValue("Qty4").ToString()
        _QPack1 = bgvMain.GetFocusedRowCellValue("QtyPack1").ToString()
        _QPack2 = bgvMain.GetFocusedRowCellValue("QtyPack2").ToString()
        _QPack3 = bgvMain.GetFocusedRowCellValue("QtyPack3").ToString()
        _QPack4 = bgvMain.GetFocusedRowCellValue("QtyPack4").ToString()
        _BomFlag = bgvMain.GetFocusedRowCellValue("BOMFlag").ToString()
        _WHInternalid = lookWarehouse.EditValue
        _Destination = 2
        _DestinationType = "Warehouse"
        _ShippingDate = "2022-06-17"
        _Transporter = "-"
        _TruckNo = "-"
        _Remarks = "-"
        _Status = "Open"
        _WHInternalID1 = 1
        _Cropyear = My.Settings.CropYear
        _UserModified = My.Settings.Username
        _InternalID = 130191
        _companyid = My.Settings.Company
        _giiservername = My.Settings.GESConnString
        _Void = 1
        _Shift = txtShift.EditValue

        'QSp_SIPInsUpdTraferWIP1.Sp_SIPInsUpdTraferWIP(_getInternalID, _InvInternalID, _WHInternalid, _Q1, _Q2, _Q3, _Q4, _QPack1, _QPack2, _QPack3, _QPack4, _BomFlag, _Destination, _DestinationType, _ShippingDate, _Transporter, _TruckNo, _Remarks, _Status, _WHInternalID1, _Cropyear, _UserModified, _InternalID, _companyid, _giiservername, _Void, _Shift)
        AlertControl1.Show(Me, "Saved Successfully", "OK")
    End Sub

    Private Sub btnExit_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnExit.ItemClick
        Me.Close()
    End Sub

    Private Sub FrmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    'Private Sub bgvMain_CellValueChanged(ByVal sender As System.Object, ByVal e As DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs) Handles bgvMain.CellValueChanged
    '    Dim View As GridView = sender
    '    Appearance.BackColor = Color.Cyan
    '    Appearance.BackColor2 = Color.Cyan
    'End Sub


    'Private Sub bgvMain_RowStyle(ByVal sender As System.Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles bgvMain.RowStyle
    '    Dim view As GridView = DirectCast(sender, GridView)
    '    If Not bgvMain.IsValidRowHandle(e.RowHandle) Then
    '        Return
    '    End If
    '    If view.GetRowCellValue(e.RowHandle, "Qty1").ToString = "-1" Then
    '        e.Appearance.BackColor = Color.Red
    '        e.HighPriority = True
    '    Else
    '        e.Appearance.BackColor = DefaultBackColor
    '    End If
    'End Sub

    Private Sub bgvMain_CellValueChanged(ByVal sender As System.Object, ByVal e As DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs) Handles bgvMain.CellValueChanged

    End Sub

    Private Sub gridView1_ShownEditor(ByVal sender As Object, ByVal e As EventArgs)
        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = TryCast(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Dim edit As BaseEdit = TryCast(view.ActiveEditor, BaseEdit)
        If edit IsNot Nothing Then
            edit.BackColor = Color.CadetBlue
        End If
    End Sub
End Class